#!/usr/bin/env python3
"""
GPSS Lead Finder
Collects business leads from free, public sources and merges them into one CSV
that the GPSS Lead Desk app imports.

Sources
  osm      OpenStreetMap business listings for a city and category
  rss      Google Alerts (or any RSS/Atom) feeds, such as "grand opening" alerts
  socrata  City, county, and state open-data portals (new licenses, permits)

Needs only Python 3.8+. Nothing to install.

One-off search
  python3 leadfinder.py --city "Rochester, NY" --category restaurant --no-website
  python3 leadfinder.py --list-categories

Automatic runs (what the nightly GitHub job uses)
  python3 leadfinder.py --config config.json --out data/leads.csv

Be a good citizen of the free services this uses: it waits between requests,
identifies itself, and should not be run in a tight loop. Put your email in
config.json ("contact") so the map servers can reach you if something is wrong.
"""
import argparse
import csv
import datetime
import html
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

NOMINATIM = "https://nominatim.openstreetmap.org/search"
OVERPASS = "https://overpass-api.de/api/interpreter"

# Friendly name -> list of (key, value) OpenStreetMap tags
CATEGORIES = {
    "restaurant": [("amenity", "restaurant")],
    "fast food": [("amenity", "fast_food")],
    "cafe": [("amenity", "cafe")],
    "bar": [("amenity", "bar"), ("amenity", "pub")],
    "bakery": [("shop", "bakery")],
    "food truck": [("amenity", "fast_food"), ("amenity", "restaurant")],  # OSM rarely tags trucks separately
    "barber": [("shop", "hairdresser"), ("shop", "barber")],
    "salon": [("shop", "hairdresser"), ("shop", "beauty")],
    "nails": [("shop", "beauty")],
    "boutique": [("shop", "clothes"), ("shop", "boutique")],
    "gift shop": [("shop", "gift")],
    "auto repair": [("shop", "car_repair")],
    "car wash": [("amenity", "car_wash")],
    "daycare": [("amenity", "childcare"), ("amenity", "kindergarten")],
    "gym": [("leisure", "fitness_centre")],
    "dentist": [("amenity", "dentist")],
    "contractor": [("craft", "builder"), ("craft", "electrician"), ("craft", "plumber"),
                   ("craft", "carpenter"), ("craft", "roofer"), ("craft", "hvac")],
    "cleaning": [("shop", "dry_cleaning"), ("shop", "laundry")],
    "real estate": [("office", "estate_agent")],
    "insurance": [("office", "insurance")],
    "accountant": [("office", "accountant")],
    "lawyer": [("office", "lawyer")],
    "florist": [("shop", "florist")],
    "pet": [("shop", "pet"), ("amenity", "veterinary")],
}

FIELDS = ["business", "contact", "email", "phone", "website", "address", "source", "notes"]
ALL_FIELDS = FIELDS + ["added"]


# ---------------------------------------------------------------- HTTP

def http_text(url, data=None, user_agent="GPSS-LeadFinder/1.0", timeout=90):
    req = urllib.request.Request(url, data=data, headers={"User-Agent": user_agent})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="replace")


def http_json(url, data=None, user_agent="GPSS-LeadFinder/1.0", timeout=90):
    return json.loads(http_text(url, data=data, user_agent=user_agent, timeout=timeout))


# ---------------------------------------------------------------- OpenStreetMap

def geocode(city, user_agent):
    """Return (south, north, west, east) bounding box for a place name."""
    params = urllib.parse.urlencode({"q": city, "format": "json", "limit": 1})
    results = http_json(NOMINATIM + "?" + params, user_agent=user_agent)
    if not results:
        raise ValueError("Could not find that place: %s" % city)
    s, n, w, e = (float(x) for x in results[0]["boundingbox"])
    return s, n, w, e


def build_query(tags, bbox):
    s, n, w, e = bbox
    parts = []
    for key, value in tags:
        parts.append('nwr["%s"="%s"]["name"](%f,%f,%f,%f);' % (key, value, s, w, n, e))
    return "[out:json][timeout:60];(%s);out center tags;" % "".join(parts)


def format_address(tags):
    street = " ".join(x for x in (tags.get("addr:housenumber"), tags.get("addr:street")) if x)
    city = tags.get("addr:city", "")
    state = tags.get("addr:state", "")
    postcode = tags.get("addr:postcode", "")
    tail = " ".join(x for x in (state, postcode) if x)
    return ", ".join(x for x in (street, city, tail) if x)


def element_to_row(el):
    tags = el.get("tags", {})
    name = tags.get("name", "").strip()
    if not name:
        return None
    phone = tags.get("phone") or tags.get("contact:phone") or ""
    email = tags.get("email") or tags.get("contact:email") or ""
    website = tags.get("website") or tags.get("contact:website") or tags.get("url") or ""
    notes = []
    if not website:
        notes.append("No website listed")
    if not phone and not email:
        notes.append("No phone or email listed")
    return {
        "business": name,
        "contact": "",
        "email": email.split(";")[0].strip(),
        "phone": phone.split(";")[0].strip(),
        "website": website.strip(),
        "address": format_address(tags),
        "source": "OpenStreetMap",
        "notes": "; ".join(notes),
    }


def rows_from_response(data, no_website=False, with_phone=False):
    seen = set()
    rows = []
    for el in data.get("elements", []):
        row = element_to_row(el)
        if not row:
            continue
        key = (row["business"].lower(), row["address"].lower())
        if key in seen:
            continue
        seen.add(key)
        if no_website and row["website"]:
            continue
        if with_phone and not (row["phone"] or row["email"]):
            continue
        rows.append(row)
    return rows


def search_osm(entry, ua, geo_cache):
    cat = str(entry.get("category", "")).strip().lower()
    if cat not in CATEGORIES:
        raise ValueError("Unknown category '%s'" % cat)
    city = entry["city"]
    if city not in geo_cache:
        geo_cache[city] = geocode(city, ua)
        time.sleep(1.1)  # Nominatim asks for at most one request per second
    query = build_query(CATEGORIES[cat], geo_cache[city])
    data = http_json(OVERPASS, data=urllib.parse.urlencode({"data": query}).encode("utf-8"), user_agent=ua)
    rows = rows_from_response(data, no_website=bool(entry.get("no_website")),
                              with_phone=bool(entry.get("with_contact")))
    for r in rows:
        r["source"] = "OpenStreetMap: %s in %s" % (cat, city)
    time.sleep(2)
    return rows


# ---------------------------------------------------------------- RSS / Atom (Google Alerts)

TAG_RE = re.compile(r"<[^>]+>")


def clean_text(s):
    return re.sub(r"\s+", " ", html.unescape(TAG_RE.sub("", s or ""))).strip()


def real_url(href):
    """Google Alerts wraps links in a redirect; pull out the real address."""
    try:
        parsed = urllib.parse.urlparse(href)
        if parsed.netloc.endswith("google.com") and parsed.path == "/url":
            q = urllib.parse.parse_qs(parsed.query)
            if q.get("url"):
                return q["url"][0]
    except ValueError:
        pass
    return href


def rows_from_feed(xml_text, name):
    root = ET.fromstring(xml_text)
    rows = []
    atom = "{http://www.w3.org/2005/Atom}"
    entries = root.findall(atom + "entry") or root.findall(".//item")
    for ent in entries:
        title = ent.findtext(atom + "title") or ent.findtext("title") or ""
        link = ""
        link_el = ent.find(atom + "link")
        if link_el is not None and link_el.get("href"):
            link = link_el.get("href")
        else:
            link = ent.findtext("link") or ""
        title = clean_text(title)
        if not title:
            continue
        rows.append({
            "business": title[:140],
            "contact": "", "email": "", "phone": "", "address": "",
            "website": real_url(link),
            "source": "Alert: %s" % name,
            "notes": "News mention, not a confirmed lead. Open the link and find the owner.",
        })
    return rows


def search_rss(entry, ua, _geo):
    return rows_from_feed(http_text(entry["url"], user_agent=ua), entry.get("name", "feed"))


# ---------------------------------------------------------------- Open-data portals (Socrata)

def rows_from_socrata(records, fields, name):
    """fields maps our column names to the portal's field names, e.g. {"business": "dba_name"}.
    A value can list several portal fields joined with a space: ["address", "city"]."""
    def pick(rec, spec):
        if not spec:
            return ""
        if isinstance(spec, str):
            spec = [spec]
        parts = []
        for f in spec:
            v = rec.get(f, "")
            if isinstance(v, dict):  # location or url style objects
                v = v.get("url") or v.get("human_address") or ""
            if v:
                parts.append(str(v).strip())
        return " ".join(parts)
    rows = []
    for rec in records:
        biz = pick(rec, fields.get("business"))
        if not biz:
            continue
        rows.append({
            "business": biz,
            "contact": pick(rec, fields.get("contact")),
            "email": pick(rec, fields.get("email")),
            "phone": pick(rec, fields.get("phone")),
            "website": pick(rec, fields.get("website")),
            "address": pick(rec, fields.get("address")),
            "source": "Open data: %s" % name,
            "notes": pick(rec, fields.get("notes")),
        })
    return rows


def search_socrata(entry, ua, _geo):
    params = {"$limit": str(entry.get("limit", 200))}
    if entry.get("order"):
        params["$order"] = entry["order"]
    if entry.get("where"):
        params["$where"] = entry["where"]
    url = entry["url"] + ("&" if "?" in entry["url"] else "?") + urllib.parse.urlencode(params)
    records = http_json(url, user_agent=ua)
    return rows_from_socrata(records, entry.get("fields", {}), entry.get("name", "portal"))


SEARCHERS = {"osm": search_osm, "rss": search_rss, "socrata": search_socrata}


# ---------------------------------------------------------------- merge + files

def row_key(r):
    anchor = (r.get("address") or r.get("phone") or r.get("website") or "").strip().lower()
    return (r.get("business", "").strip().lower(), anchor)


def read_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def write_csv(rows, path):
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=ALL_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def merge(existing, new_rows, today, keep_days=0):
    """Add rows we have not seen. Keep old rows so a lead never reappears as new."""
    known = {row_key(r) for r in existing}
    added = 0
    out = list(existing)
    for r in new_rows:
        k = row_key(r)
        if k in known or not k[0]:
            continue
        known.add(k)
        r = dict(r)
        r["added"] = today
        out.append(r)
        added += 1
    if keep_days:
        cutoff = (datetime.date.fromisoformat(today) - datetime.timedelta(days=keep_days)).isoformat()
        out = [r for r in out if (r.get("added") or today) >= cutoff]
    out.sort(key=lambda r: (r.get("added") or "", r.get("business", "").lower()), reverse=False)
    out.sort(key=lambda r: r.get("added") or "", reverse=True)
    return out, added


def run_config(config_path, out_path, today=None):
    with open(config_path, encoding="utf-8") as fh:
        cfg = json.load(fh)
    ua = "GPSS-LeadFinder/1.0 (%s)" % (cfg.get("contact") or "no contact given")
    searches = [s for s in cfg.get("searches", []) if s.get("enabled", True)]
    if not searches:
        print("No searches are turned on in %s. Edit it, set \"enabled\": true, and run again." % config_path)
        return 0
    today = today or datetime.date.today().isoformat()
    geo_cache = {}
    collected = []
    failures = 0
    for s in searches:
        label = s.get("name") or "%s %s" % (s.get("type"), s.get("city") or s.get("url", ""))
        fn = SEARCHERS.get(s.get("type"))
        if not fn:
            print("Skipping '%s': unknown type '%s'" % (label, s.get("type")))
            failures += 1
            continue
        try:
            rows = fn(s, ua, geo_cache)
            print("%-40s %d rows" % (label[:40], len(rows)))
            collected.extend(rows)
        except urllib.error.HTTPError as err:
            print("Problem with '%s': server returned HTTP %d" % (label, err.code))
            failures += 1
        except (urllib.error.URLError, TimeoutError) as err:
            print("Problem with '%s': could not connect (%s)" % (label, err))
            failures += 1
        except (ValueError, KeyError, ET.ParseError) as err:
            print("Problem with '%s': %s" % (label, err))
            failures += 1
    existing = read_csv(out_path)
    merged, added = merge(existing, collected, today, keep_days=int(cfg.get("keep_days", 0) or 0))
    write_csv(merged, out_path)
    print("Added %d new leads. %d total in %s." % (added, len(merged), out_path))
    if failures == len(searches):
        return 1
    return 0


# ---------------------------------------------------------------- one-off command line

def main(argv=None):
    p = argparse.ArgumentParser(description="Collect business leads from free public sources into a CSV.")
    p.add_argument("--config", help="Run every search turned on in this JSON file")
    p.add_argument("--city", help='Place name, e.g. "Rochester, NY"')
    p.add_argument("--category", help="Business type. Use --list-categories to see choices.")
    p.add_argument("--no-website", action="store_true", help="Keep only businesses with no website listed")
    p.add_argument("--with-contact", action="store_true", help="Keep only businesses with a phone or email listed")
    p.add_argument("--out", help="Output CSV path")
    p.add_argument("--contact", default="", help="Your email or site, sent so map servers can reach you")
    p.add_argument("--list-categories", action="store_true", help="Show built-in categories and exit")
    args = p.parse_args(argv)

    if args.list_categories:
        for name in sorted(CATEGORIES):
            print(name)
        return 0

    if args.config:
        return run_config(args.config, args.out or "data/leads.csv")

    if not args.city or not args.category:
        p.error("use --config FILE, or give both --city and --category")

    cat = args.category.strip().lower()
    if cat not in CATEGORIES:
        close = [c for c in CATEGORIES if cat in c or c in cat]
        hint = (" Did you mean: %s?" % ", ".join(close)) if close else " Run with --list-categories."
        raise SystemExit("Unknown category '%s'.%s" % (args.category, hint))

    ua = "GPSS-LeadFinder/1.0 (%s)" % (args.contact or "no contact given")
    try:
        print("Searching %s in %s ..." % (cat, args.city))
        rows = search_osm({"city": args.city, "category": cat, "no_website": args.no_website,
                           "with_contact": args.with_contact}, ua, {})
    except urllib.error.HTTPError as err:
        if err.code in (429, 504):
            raise SystemExit("The free map server is busy (HTTP %d). Wait a few minutes and try again, "
                             "or try a smaller area." % err.code)
        raise SystemExit("The map server returned an error (HTTP %d)." % err.code)
    except (urllib.error.URLError, TimeoutError) as err:
        raise SystemExit("Could not reach the map servers. Check your internet connection and try again. (%s)" % err)
    except ValueError as err:
        raise SystemExit(str(err))

    safe = lambda s: "".join(ch if ch.isalnum() else "-" for ch in s.lower()).strip("-")
    out = args.out or "leads-%s-%s.csv" % (safe(args.city), safe(cat))
    merged, added = merge(read_csv(out), rows, datetime.date.today().isoformat())
    write_csv(merged, out)
    print("Saved %d leads (%d new) to %s" % (len(merged), added, out))
    print("Next: open GPSS Lead Desk > Pipeline > Import file, and choose that CSV.")
    print("Tip: check each business's own site or Facebook page before you contact them.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
